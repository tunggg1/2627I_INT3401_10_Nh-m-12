# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        score = successorGameState.getScore()

        foodList = newFood.asList()
        if foodList:
            nearestFood = min(manhattanDistance(newPos, f) for f in foodList)
            score += 2.0 / nearestFood if nearestFood > 0 else 2.0
            score -= 0.5 * len(foodList)

        for ghost, scared in zip(newGhostStates, newScaredTimes):
            d = manhattanDistance(newPos, ghost.getPosition())
            if scared > d:
                score += 3.0 / (d + 1)
            elif d <= 1:
                score -= 500
            else:
                score -= 2.0 / d

        if action == Directions.STOP:
            score -= 2
        return score

def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        numAgents = gameState.getNumAgents()

        def nextTurn(agent, depth):
            nxt = (agent + 1) % numAgents
            return nxt, (depth + 1 if nxt == 0 else depth)

        def value(state, agent, depth):
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)
            nxt, nxtDepth = nextTurn(agent, depth)
            values = [value(state.generateSuccessor(agent, a), nxt, nxtDepth)
                      for a in state.getLegalActions(agent)]
            return max(values) if agent == 0 else min(values)

        nxt, nxtDepth = nextTurn(0, 0)
        bestScore, bestAction = float('-inf'), None
        for action in gameState.getLegalActions(0):
            score = value(gameState.generateSuccessor(0, action), nxt, nxtDepth)
            if score > bestScore:
                bestScore, bestAction = score, action
        return bestAction


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        numAgents = gameState.getNumAgents()

        def nextTurn(agent, depth):
            nxt = (agent + 1) % numAgents
            return nxt, (depth + 1 if nxt == 0 else depth)

        def value(state, agent, depth, alpha, beta):
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)
            nxt, nxtDepth = nextTurn(agent, depth)
            if agent == 0:
                v = float('-inf')
                for a in state.getLegalActions(agent):
                    v = max(v, value(state.generateSuccessor(agent, a),
                                     nxt, nxtDepth, alpha, beta))
                    if v > beta:
                        return v
                    alpha = max(alpha, v)
                return v
            else:
                v = float('inf')
                for a in state.getLegalActions(agent):
                    v = min(v, value(state.generateSuccessor(agent, a),
                                     nxt, nxtDepth, alpha, beta))
                    if v < alpha:
                        return v
                    beta = min(beta, v)
                return v

        alpha, beta = float('-inf'), float('inf')
        nxt, nxtDepth = nextTurn(0, 0)
        bestScore, bestAction = float('-inf'), None
        for action in gameState.getLegalActions(0):
            score = value(gameState.generateSuccessor(0, action),
                          nxt, nxtDepth, alpha, beta)
            if score > bestScore:
                bestScore, bestAction = score, action
            alpha = max(alpha, bestScore)
        return bestAction


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        numAgents = gameState.getNumAgents()

        def nextTurn(agent, depth):
            nxt = (agent + 1) % numAgents
            return nxt, (depth + 1 if nxt == 0 else depth)

        def value(state, agent, depth):
            if state.isWin() or state.isLose() or depth == self.depth:
                return self.evaluationFunction(state)
            nxt, nxtDepth = nextTurn(agent, depth)
            values = [value(state.generateSuccessor(agent, a), nxt, nxtDepth)
                      for a in state.getLegalActions(agent)]
            return max(values) if agent == 0 else sum(values) / len(values)

        nxt, nxtDepth = nextTurn(0, 0)
        bestScore, bestAction = float('-inf'), None
        for action in gameState.getLegalActions(0):
            score = value(gameState.generateSuccessor(0, action), nxt, nxtDepth)
            if score > bestScore:
                bestScore, bestAction = score, action
        return bestAction


def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: Starts from the game score, then adds the reciprocal of the
    distance to the nearest food, penalizes remaining food and capsules (so
    Pacman keeps eating), rewards chasing scared ghosts, and strongly
    penalizes being next to an active ghost.
    """
    pos = currentGameState.getPacmanPosition()
    foodList = currentGameState.getFood().asList()
    capsules = currentGameState.getCapsules()
    ghostStates = currentGameState.getGhostStates()

    score = currentGameState.getScore()

    if foodList:
        distances = [manhattanDistance(pos, f) for f in foodList]
        score += 10.0 / min(distances) if min(distances) > 0 else 10.0
        score -= 4.0 * len(foodList)

    score -= 15.0 * len(capsules)

    for ghost in ghostStates:
        d = manhattanDistance(pos, ghost.getPosition())
        if ghost.scaredTimer > d:
            score += 200.0 / (d + 1)
        elif d < 2:
            score -= 300
        else:
            score -= 3.0 / d
    return score

# Abbreviation
better = betterEvaluationFunction
